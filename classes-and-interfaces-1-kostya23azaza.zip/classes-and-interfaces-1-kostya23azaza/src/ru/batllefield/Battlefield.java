package ru.batllefield;

import ru.batllefield.units.*;

/**
 * Главный класс, содержащий метод main
 */
public class Battlefield {

    public static short sShootPower = 12;
    public static short sHealth = 50;
    public static  short sArmor = 2;

    /**
     * Главный метод приложения - точка входа (запуска).
     * @param args аргументы, которые передаются при запуске приложения.
     */
    public static void main(String[] args) {
        Tank tank1 = new Tank((short) 40,(short) 80);
        Soldier soldier1 = new Soldier(sShootPower, sHealth, sArmor);
        Soldier soldier2 = new Soldier(sShootPower, sHealth, sArmor);
        Transport transport = new Transport((short) 4, (short) 80);

        soldier1.shoot(soldier2);
        soldier1.shoot(transport);
        tank1.shoot(transport);
        tank1.shoot(soldier1);

      //  System.out.println(tank1.toString());
       // System.out.println(soldier1.toString());
       // System.out.println(soldier2.toString());
       // System.out.println(transport.toString());

        AbstractArmyUnit[] army2 = new AbstractArmyUnit[5];
        army2[0] = new Soldier(sShootPower,sHealth,sArmor);
        army2[1] = new Medic(sHealth,sArmor);
        army2[2] = new Tank((short)40,(short)80);
        army2[3] = new Transport((short) 4, (short) 80);
        army2[4] = new Soldier(sShootPower,sHealth,sArmor);



        AbstractArmyUnit[] army1 = new AbstractArmyUnit[7];
        army1[0] = new Soldier(sShootPower, sHealth, sArmor);
        army1[1] = new Transport((short) 4, (short) 80);
        army1[2] = new Soldier(sShootPower, sHealth, sArmor);
        army1[3] = new Transport((short) 4, (short) 80);
        army1[4] = new Tank((short)40,(short)80);
        army1[5] = new Tank((short)40,(short)80);
        army1[6] = new Medic(sHealth,sArmor);




        for (int i = 0; i < army1.length; i++) { //все делают 4 выстрела
            if (army1[i] instanceof Shooter){
            for(int j = 0; j < army2.length; j++) { //каждый из армии
                if(army2[j] instanceof Shootable) { // если стрелок
                    Shooter shooter = (Shooter) army1[i];
                    Shootable looser = (Shootable) army2[j];// приводим тип
                    shooter.shoot(looser); // стреляем
                }
                }
            }

        }
        for (int i = 0; i < army2.length; i++) { //все делают 4 выстрела
            if (army2[i] instanceof Shooter){
                for(int j = 0; j < army1.length; j++) { //каждый из армии
                    if(army1[j] instanceof Shootable) { // если стрелок
                        Shooter shooter = (Shooter) army2[i];
                        Shootable looser = (Shootable) army1[j];// приводим тип
                        shooter.shoot(looser); // стреляем
                    }
                }
            }

        }
        System.out.println("Army1");
        for(byte ind = 0;ind<army1.length;ind++)
            System.out.println(army1[ind].toString());

        System.out.println("\nArmy2");
        for(byte ind = 0;ind<army2.length;ind++)
            System.out.println(army2[ind].toString());

    }

}
