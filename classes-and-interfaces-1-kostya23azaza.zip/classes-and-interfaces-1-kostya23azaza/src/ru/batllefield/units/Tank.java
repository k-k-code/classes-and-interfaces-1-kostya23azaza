package ru.batllefield.units;

public class Tank extends AbstractMachine implements Shooter {
    /**
     * Конструктор.
     *
     * @param fuel остаток топлива.
     */

    private short shootPower;
    public Tank(short shootPower, short fuel) {
        super(fuel);
        this.shootPower = shootPower; // установка значения силы выстрела.
    }


    @Override
    public void shoot(Shootable target) {
        target.getShot(shootPower);
    }
}
