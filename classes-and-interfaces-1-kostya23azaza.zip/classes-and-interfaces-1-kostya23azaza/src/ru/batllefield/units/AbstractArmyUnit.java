package ru.batllefield.units;

/**
 * Абстрактный класс - общий родитель для всех боевых единиц.
 */
public abstract class AbstractArmyUnit {


}
